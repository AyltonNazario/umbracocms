export const environment = {
  production: true,
  assetsURL: ""
};
