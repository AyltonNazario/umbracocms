import { Component } from '@angular/core';
import { Router } from '@angular/router';

export interface CarouselItem {
  description: string;
  img: string;
}

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {

  carouselItems: CarouselItem[] = [{ description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus ut ante lorem. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae; Nullam et mi dolor. Nullam vel nisi sit amet sem sagittis tempus. Donec enim elit, ultricies non risus non, eleifend faucibus purus. Aliquam in elit massa. In ac purus vel ex molestie eleifend ut a orci. Integer eleifend egestas sapien, ac pretium magna elementum a. Nunc commodo facilisis orci, in posuere dolor pulvinar at. Donec aliquam pellentesque mauris nec tristique. Cras orci lorem, condimentum vel porttitor non, condimentum a lorem.", img: "assets/hi-tech-enterprise-smart-assistant.jpg" },
  { description: "Aliquam ullamcorper laoreet malesuada. Aliquam metus nisi, posuere blandit dignissim sit amet, sodales non libero. Morbi tincidunt quis quam a consequat. Donec fermentum blandit metus. Donec in sollicitudin urna. Duis ornare vitae ipsum non viverra. Donec vitae massa elit. Proin quis faucibus diam. Donec ornare dapibus metus nec scelerisque. Maecenas varius eros vel nunc vestibulum, id facilisis urna finibus. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Nulla dignissim turpis id sem venenatis faucibus.", img: "assets/lightbulb-illuminating-floor-background.jpg" }];
  carouselImgNF: string = 'assets/images/carousel-img-notfound.png';
  currentSlide: number = 0;

  constructor(protected router: Router) {}

  ngOnInit(): void {
  }

  onPreviousClick() {
    const previous = this.currentSlide - 1;
    this.currentSlide = previous < 0 ? this.carouselItems?.length - 1 : previous;
  }

  onNextClick() {
    const next = this.currentSlide + 1;
    this.currentSlide = next === this.carouselItems?.length ? 0 : next;
  }

  setCurrent($event: any) {
    this.currentSlide = +$event.target.id;
  }

  ngOnDestroy() {
  }
}
